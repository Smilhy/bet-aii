-- BET+AI version 228 — bezpieczne przywrócenie logiki dashboardu
-- Nie usuwa danych. Nie aktualizuje kolumn generated, np. is_premium.

ALTER TABLE public.tips
  ADD COLUMN IF NOT EXISTS ai_confidence integer DEFAULT 85,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS result text DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS profit numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS odds numeric DEFAULT 1.0,
  ADD COLUMN IF NOT EXISTS stake numeric DEFAULT 1,
  ADD COLUMN IF NOT EXISTS access_type text DEFAULT 'free',
  ADD COLUMN IF NOT EXISTS price numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS analysis text,
  ADD COLUMN IF NOT EXISTS ai_probability integer,
  ADD COLUMN IF NOT EXISTS ai_score integer,
  ADD COLUMN IF NOT EXISTS ai_analysis text,
  ADD COLUMN IF NOT EXISTS author_name text,
  ADD COLUMN IF NOT EXISTS author_email text,
  ADD COLUMN IF NOT EXISTS username text,
  ADD COLUMN IF NOT EXISTS match text,
  ADD COLUMN IF NOT EXISTS prediction text,
  ADD COLUMN IF NOT EXISTS league text,
  ADD COLUMN IF NOT EXISTS team_home text,
  ADD COLUMN IF NOT EXISTS team_away text,
  ADD COLUMN IF NOT EXISTS match_time timestamptz,
  ADD COLUMN IF NOT EXISTS bet_type text,
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS notify_followers boolean DEFAULT true;

UPDATE public.tips
SET
  ai_confidence = COALESCE(ai_confidence, ai_probability, 85),
  status = COALESCE(status, 'pending'),
  result = COALESCE(result, 'pending'),
  profit = COALESCE(profit, 0),
  odds = COALESCE(odds, 1.0),
  stake = COALESCE(stake, 1),
  access_type = COALESCE(access_type, 'free'),
  price = COALESCE(price, 0),
  tags = COALESCE(tags, '{}'),
  notify_followers = COALESCE(notify_followers, true)
WHERE true;

CREATE OR REPLACE VIEW public.tips_free AS
SELECT *
FROM public.tips
WHERE access_type = 'free'
ORDER BY created_at DESC;

CREATE OR REPLACE VIEW public.tips_premium AS
SELECT *
FROM public.tips
WHERE access_type = 'premium'
ORDER BY created_at DESC;

CREATE OR REPLACE VIEW public.tips_all AS
SELECT *
FROM public.tips
ORDER BY created_at DESC;

CREATE OR REPLACE VIEW public.user_tip_stats AS
SELECT
  COALESCE(user_id, author_id) AS user_id,
  COUNT(*) AS total_tips,
  SUM(CASE WHEN result = 'win' THEN 1 ELSE 0 END) AS wins,
  SUM(CASE WHEN result = 'lose' THEN 1 ELSE 0 END) AS losses,
  COALESCE(SUM(profit), 0) AS total_profit,
  ROUND(
    CASE WHEN COUNT(*) = 0 THEN 0
    ELSE (SUM(CASE WHEN result = 'win' THEN 1 ELSE 0 END)::numeric / COUNT(*)) * 100 END,
    2
  ) AS winrate
FROM public.tips
GROUP BY COALESCE(user_id, author_id);

CREATE OR REPLACE VIEW public.tipster_ranking AS
SELECT
  COALESCE(user_id, author_id) AS tipster_id,
  COALESCE(MAX(author_name), MAX(username), 'Tipster') AS tipster_name,
  COUNT(*) AS total_tips,
  SUM(CASE WHEN access_type = 'premium' THEN 1 ELSE 0 END) AS premium_tips,
  COALESCE(SUM(profit), 0) AS profit,
  COALESCE(SUM(CASE WHEN access_type = 'premium' THEN price ELSE 0 END), 0) AS earnings,
  ROUND(
    CASE WHEN COUNT(*) = 0 THEN 0
    ELSE (SUM(CASE WHEN result = 'win' THEN 1 ELSE 0 END)::numeric / COUNT(*)) * 100 END,
    2
  ) AS winrate
FROM public.tips
GROUP BY COALESCE(user_id, author_id)
ORDER BY earnings DESC, profit DESC, total_tips DESC;

CREATE OR REPLACE FUNCTION public.calculate_tip_profit_v228()
RETURNS trigger AS $$
BEGIN
  IF NEW.result = 'win' THEN
    NEW.profit := (COALESCE(NEW.odds, 1) - 1) * COALESCE(NEW.stake, 1);
  ELSIF NEW.result = 'lose' THEN
    NEW.profit := -COALESCE(NEW.stake, 1);
  ELSE
    NEW.profit := COALESCE(NEW.profit, 0);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_calculate_tip_profit_v228 ON public.tips;
CREATE TRIGGER trigger_calculate_tip_profit_v228
BEFORE INSERT OR UPDATE OF result, odds, stake ON public.tips
FOR EACH ROW
EXECUTE FUNCTION public.calculate_tip_profit_v228();

CREATE INDEX IF NOT EXISTS idx_tips_created_at_v228 ON public.tips(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tips_user_id_v228 ON public.tips(user_id);
CREATE INDEX IF NOT EXISTS idx_tips_author_id_v228 ON public.tips(author_id);
CREATE INDEX IF NOT EXISTS idx_tips_access_type_v228 ON public.tips(access_type);

NOTIFY pgrst, 'reload schema';
